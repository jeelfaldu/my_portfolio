<nav class="navbar">

<ul class="navbar-list">

  <li class="navbar-item">
    <a href="#about" class="navbar-link  active" data-nav-link>About</a>
  </li>

  <li class="navbar-item">
    <a href="#resume" class="navbar-link" data-nav-link>Resume</a>
  </li>

  <!-- <li class="navbar-item">
    <button class="navbar-link" data-nav-link>Portfolio</button>
  </li> -->

  <li class="navbar-item">
    <a href="#blog" class="navbar-link" data-nav-link>Blog</a>
  </li>

  <li class="navbar-item">
    <a href="#contact" class="navbar-link" data-nav-link>Contact</a>
  </li>

</ul>

</nav>